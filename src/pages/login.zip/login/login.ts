import { Component } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { IonicPage, NavController, ToastController } from 'ionic-angular';
import { LoadingController } from 'ionic-angular';
import { NativeStorage } from '@ionic-native/native-storage';
import { Storage } from '@ionic/storage';


import { User } from '../../providers/providers';
import { MainPage } from '../pages';
import { SignupPage } from '../signup/signup';


@IonicPage()
@Component({
  selector: 'page-login',
  templateUrl: 'login.html'
})
export class LoginPage {
  // The account fields for the login form.
  // If you're using the username field with or without email, make
  // sure to add it to the type
  name:any;
  account: { mobile: string, password: string, type:string } = {
    mobile: '9962992809',
    password: 'testme',
    type: 'vendor'
  };

  mobile:any;
  password:any;
  userdata:any;

  // Our translated text strings
  private loginErrorString: string;

  constructor(public navCtrl: NavController,
    public user: User,
    public toastCtrl: ToastController,
    public storage: Storage,    
    public translateService: TranslateService,
    public loadingCtrl: LoadingController,
    public nativeStorage: NativeStorage) {

    this.translateService.get('LOGIN_ERROR').subscribe((value) => {
      this.loginErrorString = value;
    })
  }

  ionViewDidLoad(){
    
        this.GetuserData();
    
      }
    


  GetuserData(){
    
        this.storage.get('UserData')
        .then(
        data => {
          this.mobile = data.mobile;
          this.password = data.password;
          console.log("user data",this.mobile);
          try{

            this.LoginCheck(this.mobile,this.password);
            
          }catch (e) {
            console.log(e);
          }
          
        },
        error => console.error(error)
      
        );
      }

  // Attempt to login in through our User service
  LoginCheck(mobile,password){
    
        if(mobile == "loggedout" && password == "loggedout"){
          
                console.log("logged out");
              }else{
                
              let  account: { mobile: string, password: string, type:string } = {
                  mobile: mobile,
                  password: password,
                  type: 'vendor'
                };
                // console.log("logged in");
                this.login(account);
                // this.presentLoading();
                            
              }
      }

      login(account){

        this.user.login(account).subscribe((resp) => {
          // this.navCtrl.push(MainPage);
          this.userdata = resp;
          console.log(this.userdata.data);
          this.storage.set('UserData', {mobile: this.account.mobile , password: this.account.password, type: this.account.type,userid:this.userdata.data.id,walletbalance:this.userdata.data.rf_wallet_bal})
      .then(
        () => console.log('Stored item!'),
        error => console.error('Error storing item', error)
      );
          this.presentLoading();
        }, (err) => {
          // Unable to log in
          let toast = this.toastCtrl.create({
            message: this.loginErrorString,
            duration: 3000,
            position: 'top'
          });
          toast.present();
        });
      }
      // Attempt to login in through our User service
      doLogin() {
        this.user.login(this.account).subscribe((resp) => {
          // this.navCtrl.push(MainPage);
          this.userdata = resp;
          console.log(this.userdata.data);
          this.storage.set('UserData', {mobile: this.account.mobile , password: this.account.password, type: this.account.type,userid:this.userdata.data.id,walletbalance:this.userdata.data.rf_wallet_bal})
      .then(
        () => console.log('Stored item!'),
        error => console.error('Error storing item', error)
      );
          this.presentLoading();
        }, (err) => {
          // this.navCtrl.push(MainPage);
          // this.presentLoading();
          // Unable to log in
          let toast = this.toastCtrl.create({
            message: this.loginErrorString,
            duration: 3000,
            position: 'top'
          });
          toast.present();
        });
      }

  presentLoading() {
    let loader = this.loadingCtrl.create({
      content: "verifying..",
      duration: 3000
    });
    loader.present();

    setTimeout(() => {
      this.navCtrl.push(MainPage);
    }, 1000);
  }

  signup(){

    this.navCtrl.push(SignupPage);
  }
}
